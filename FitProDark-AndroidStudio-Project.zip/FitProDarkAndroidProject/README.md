# FitPro Dark — Android UI prototype

A standalone Android app wrapping a WHOOP-inspired dark UI prototype in a local WebView. The sample UI includes Today, Device, Train, and Profile screens.

## Important limitations
- This is a UI prototype, not a modified version of the original FitPro app.
- Health values, device status, workout history, and settings are demo/sample content.
- It does not connect to the original wearable, sensors, account, or health APIs.
- It has not been compiled or tested in this environment.

## Build the APK using GitHub on your phone
1. Create a new repository on https://github.com/ and set it to **Public** (or use a private repo if you know how to enable Actions).
2. Upload the contents of this project folder to the repository root. Do not upload only the ZIP file. Include the `.github/workflows/build-apk.yml` file; on Android, enable “Show hidden files” if needed.
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Select **Build Android APK** on the left, tap **Run workflow**, then run it on the default branch.
5. When it finishes successfully, open that workflow run and download the **FitProDark-debug-apk** artifact.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager.

Requires Java 17 and Gradle 8.9; the GitHub Actions workflow sets these up automatically.
